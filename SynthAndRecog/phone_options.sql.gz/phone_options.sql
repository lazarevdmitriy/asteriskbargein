DELIMITER ;;
UPDATE phone_options
	SET `options`='[general]

default-asr-profile = asr
default-tts-profile = tts
; UniMRCP logging level to appear in Asterisk logs.  Options are:
; EMERGENCY|ALERT|CRITICAL|ERROR|WARNING|NOTICE|INFO|DEBUG -->

log-level = ERROR
max-connection-count = 100
offer-new-connection = 1
; rx-buffer-size = 1024
; tx-buffer-size = 1024
; request-timeout = 5000
; speech-channel-timeout = 30000


[asr]

version = 2

#include mrcpaddr.conf

sip-transport = udp

rtp-port-min = 25000
rtp-port-max = 29000 

; === Jitter buffer settings === 
playout-delay = 50 
max-playout-delay = 200 

; === RTP settings === 
ptime = 20 
codecs = PCMU PCMA L16/96/8000 telephone-event/101/8000 

; === RTCP settings === 
rtcp = 0
;rtcp-bye = 2
;rtcp-tx-interval = 5000
;rtcp-rx-resolution = 1000

#include mrcpconnectors.conf

[tts]
; MRCP settings
version = 2
;
; SIP settings
server-ip = $TTS_SERVER
server-port = 8000
; SIP user agent
client-ip = $QA_SERVER
client-port = 8062
sip-transport = tcp
;
; RTP factory
rtp-ip = $QA_SERVER
rtp-port-min = 38000
rtp-port-max = 39000
;
; Jitter buffer settings
playout-delay = 50
max-playout-delay = 200
; RTP settings
ptime = 20
codecs = PCMU PCMA L16/96/8000 telephone-event/101/8000
; RTCP settings
rtcp = 0
'
	WHERE id='mrcp.conf';
;;